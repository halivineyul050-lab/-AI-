Page({
  data: {
    principal: '',
    rate: '',
    months: '',
    monthly: '0.00',
    totalInterest: '0.00',
    totalPayment: '0.00',
    error: ''
  },

  onPrincipalInput(e) {
    this.setData({ principal: e.detail.value, error: '' });
  },

  onRateInput(e) {
    this.setData({ rate: e.detail.value, error: '' });
  },

  onMonthsInput(e) {
    this.setData({ months: e.detail.value, error: '' });
  },

  onCalc() {
    const principalRaw = (this.data.principal || '').trim();
    const rateRaw = (this.data.rate || '').trim();
    const monthsRaw = (this.data.months || '').trim();

    if (principalRaw === '' || rateRaw === '' || monthsRaw === '') {
      this.setData({ error: '请填写贷款金额、年利率和期限' });
      return;
    }

    const principal = Number(principalRaw);
    const rate = Number(rateRaw);
    const months = Number(monthsRaw);

    if (!isFinite(principal) || !isFinite(rate) || !isFinite(months)) {
      this.setData({ error: '请输入有效数字' });
      return;
    }
    if (principal <= 0) {
      this.setData({ error: '贷款金额必须大于 0' });
      return;
    }
    if (rate < 0) {
      this.setData({ error: '年利率不能为负数' });
      return;
    }
    if (months <= 0 || Math.floor(months) !== months) {
      this.setData({ error: '期限必须为正整数（月）' });
      return;
    }

    let monthly;
    if (rate === 0) {
      monthly = principal / months;
    } else {
      const r = rate / 100 / 12;
      const pow = Math.pow(1 + r, months);
      monthly = (principal * r * pow) / (pow - 1);
    }

    const totalPayment = monthly * months;
    const totalInterest = totalPayment - principal;

    this.setData({
      monthly: this.format(monthly),
      totalInterest: this.format(totalInterest),
      totalPayment: this.format(totalPayment),
      error: ''
    });
  },

  onReset() {
    this.setData({
      principal: '',
      rate: '',
      months: '',
      monthly: '0.00',
      totalInterest: '0.00',
      totalPayment: '0.00',
      error: ''
    });
  },

  format(num) {
    if (!isFinite(num)) {
      return '0.00';
    }
    const rounded = Math.round(num * 100) / 100;
    return rounded.toFixed(2);
  },

  onShareAppMessage() {
    return {
      title: '等额本息房贷计算器',
      path: 'pages/index/index'
    };
  }
});