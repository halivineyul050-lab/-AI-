# 等额本息房贷计算器

微信原生小程序工程，版本 real-native-example。工程结构已检查；微信编译、手机业务测试、审核与发布需要在微信侧完成。

1. 安装官方微信开发者工具 https://developers.weixin.qq.com/miniprogram/dev/devtools/download.html ，扫码登录并导入本目录。
2. 在 project.config.json 配置自己的 AppID（当前 touristappid），确认全部页面和组件可编译。AppID不是AppSecret，不要把AppSecret或上传私钥放进源码。
3. 在工具内点击预览生成真实二维码，使用微信扫码检查主要流程。
4. 确认版本号和说明后，手工上传开发版本；进入 https://mp.weixin.qq.com/ 版本管理补全隐私、权限、类目和必要的域名等资料，提交审核。审核通过后由管理员操作发布。

## 可选的本地命令（Node.js 22+）

在开发者工具设置/安全设置中开启服务端口。Windows例子，替换本机安装与项目路径：

    node nestdutio-wechat-devtools.mjs doctor --cli "D:/Program Files (x86)/Tencent/微信web开发者工具/cli.bat"
    node nestdutio-wechat-devtools.mjs islogin --cli "D:/Program Files (x86)/Tencent/微信web开发者工具/cli.bat"
    node nestdutio-wechat-devtools.mjs preview --cli "D:/Program Files (x86)/Tencent/微信web开发者工具/cli.bat" --project "D:/my-miniapp" --qr-output "D:/preview-new.png"

二维码必须写到尚不存在的PNG文件，以免把旧二维码误当新结果。上传是独立的显式操作：

    node nestdutio-wechat-devtools.mjs upload --cli "D:/Program Files (x86)/Tencent/微信web开发者工具/cli.bat" --project "D:/my-miniapp" --version "1.0.0" --description "首次体验"

此脚本只衔接本机官方CLI，不会自动提交审核或正式发布。官方CLI使用说明：https://developers.weixin.qq.com/miniprogram/dev/devtools/cli.html 。本工程当前只包含本地工具功能，不包含平台账号、用户数据库或跨设备后端服务。
